//
//  GuideView.swift
//  MealPal
//
//  Created by Ultiimate Dog on 11/02/24.
//

import SwiftUI

struct GuideView: View {
    @ObservedObject var modelData: ModelData = .shared
    @State var tutorialPage = 1
    let dWidth: Double
    let dHeight: Double
    
    var body: some View {
        VStack(spacing: 0) {
            switch tutorialPage {
            case 1:
                Page1(dWidth: dWidth)
            case 2:
                Page2(dWidth: dWidth, dHeight: dHeight)
            case 3:
                Page3(dWidth: dWidth, dHeight: dHeight)
            case 4:
                Page4(dWidth: dWidth, dHeight: dHeight)
            case 5:
                Page5(dWidth: dWidth, dHeight: dHeight)
            case 6:
                Page6(dWidth: dWidth, dHeight: dHeight)
            case 7:
                Page7(dWidth: dWidth, dHeight: dHeight)
            case 8:
                Page8(dWidth: dWidth, dHeight: dHeight)
            case 9:
                Page9(dWidth: dWidth, dHeight: dHeight)
            case 10:
                Page10(dWidth: dWidth, dHeight: dHeight)
            case 11:
                Page11(dWidth: dWidth, dHeight: dHeight)
            case 12:
                Page12(dWidth: dWidth, dHeight: dHeight)
            case 13:
                Page13(dWidth: dWidth, dHeight: dHeight)
            case 14:
                Page14(dWidth: dWidth, dHeight: dHeight)
            default:
                EndPage(dWidth: dWidth, dHeight: dHeight)
            }
            Spacer()
            HStack {
                if tutorialPage != 1 {
                    Button {
                        withAnimation() {
                            if tutorialPage > 1{
                                tutorialPage -= 1
                            }
                        }
                    } label: {
                        Image(systemName: "arrowshape.zigzag.forward.fill")
                            .resizable()
                            .scaledToFit()
                            .rotationEffect(.degrees(180))
                            .scaleEffect(x: 1, y: -1)
                            .frame(width: dWidth*0.1)
                }
                }
                Spacer()
                Button {
                    withAnimation() {
                        tutorialPage += 1
                        if tutorialPage > 15 {
                            modelData.showTutorial = false
                        }
                    }
                } label: {
                    Image(systemName: "arrowshape.zigzag.forward.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(width: dWidth*0.1)
                }

            }
        }
        .padding()
        .frame(width: dWidth*0.85, height: dHeight*0.8, alignment: .top)
        .background(RoundedRectangle(cornerRadius: dWidth * 0.0636).foregroundStyle(Color.black).opacity(0.9))
    }
}

struct EndPage: View {
    let dWidth: Double
    let dHeight: Double
    
    var body: some View {
        Text("You just got to the end of this tutorial.")
            .multilineTextAlignment(.center)
            .foregroundStyle(Color.white)
            .font(.title3)
        Text("Quite simple, rigth?")
            .multilineTextAlignment(.center)
            .foregroundStyle(Color.white)
            .font(.title3)
            .padding(.vertical, 7)
        Text("Well, I hope you like...")
            .multilineTextAlignment(.center)
            .foregroundStyle(Color.white)
            .font(.title3)
            .padding(.bottom, 7)
        Text("My Meal Pal")
            .foregroundStyle(Color.white)
            .font(.largeTitle)
            .bold()
            .overlay {
                LinearGradient(
                    colors: [.red, .accentColor],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .mask(
                    Text("My Meal Pal")
                        .font(.largeTitle)
                        .bold()
                )
            }
        Image("AppIcon")
            .resizable()
            .scaledToFit()
            .frame(width: dWidth*0.2)
            .padding(.bottom, 5)
        
        Text("Disclaimer")
            .multilineTextAlignment(.center)
            .foregroundStyle(Color.white)
            .font(.title2)
            .bold()
            .padding(.vertical, 10)
        Text("As the app uses the camera, is needed to be run in a physical device, otherwise the property of identifiyng food will not work.")
            .foregroundStyle(Color.white)
            .italic()
            .padding(.bottom, 10)
        Text("The machine learning model only identifies 8 meals, being them: Apple pies, Bananas, Cheese, Chocolate cakes, Hamburgers, Hot dogs, pizzas and Spaghetti bolognese")
            .foregroundStyle(Color.white)
            .italic()
            .padding(.bottom, 10)
        Text("The information about the meals is not rigth, is just there to show how it would work")
            .foregroundStyle(Color.white)
            .italic()
            .padding(.bottom, 10)
        Text("Made by Alan Perez Hernandez")
            .foregroundStyle(Color.white)
            .italic()
    }
}

// First page of the tutorial
struct Page1: View {
    let dWidth: Double

    var body: some View {
        Text("Welcome to")
            .foregroundStyle(Color.white)
            .font(.title2)
            .bold()
        Text("My Meal Pal")
            .foregroundStyle(Color.white)
            .font(.largeTitle)
            .bold()
            .overlay {
                LinearGradient(
                    colors: [.red, .accentColor],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .mask(
                    Text("My Meal Pal")
                        .font(.largeTitle)
                        .bold()
                )
            }
        Image("AppIcon")
            .resizable()
            .scaledToFit()
            .frame(width: dWidth*0.2)
            .padding(.bottom, 5)
        Text("**My Meal Pal** is an App that looks to improve the health and lifestyle of its users by giving them the tools to:")
            .font(.title3)
            .foregroundStyle(Color.white)
        HStack {
            Image(systemName: "fork.knife")
                .resizable()
                .scaledToFit()
                .frame(width: 17)
                .foregroundStyle(Color.orange)
            Spacer()
            Text("Identify what they eat with just opening the camera and pointing it to the meal")
                .font(.title3)
                .foregroundStyle(Color.white)
        }
        .padding(.leading, 10)
        .padding(.top, 10)
        HStack {
            Image(systemName: "basket.fill")
                .resizable()
                .scaledToFit()
                .frame(width: 25)
                .foregroundStyle(Color.red)
            Text("Track how many macronutrients and calories the user has eaten")
                .font(.title3)
                .foregroundStyle(Color.white)
            Spacer()
        }
        .padding(.leading, 6)
        .padding(.top, 10)
        HStack {
            Image(systemName: "trophy.fill")
                .resizable()
                .scaledToFit()
                .frame(width: 22)
                .foregroundStyle(Color.accentColor)
            Text("Set goals to help the users get their dream bodies")
                .font(.title3)
                .foregroundStyle(Color.white)
            Spacer()
        }
        .padding(.leading, 8)
        .padding(.top, 10)
        HStack {
            Image(systemName: "flame.fill")
                .resizable()
                .scaledToFit()
                .frame(width: 20)
                .foregroundStyle(Color.blue)
            Text("Keep a record of how many consecutive days the user has achieve his goals")
                .font(.title3)
                .foregroundStyle(Color.white)
            Spacer()
        }
        .padding(.leading, 10)
        .padding(.top, 10)
        HStack {
            Image(systemName: "sparkle.magnifyingglass")
                .resizable()
                .scaledToFit()
                .frame(width: 25)
                .foregroundStyle(Color.green)
            Text("Search for a variety of food in an extensive database")
                .font(.title3)
                .foregroundStyle(Color.white)
            Spacer()
        }
        .padding(.leading, 5)
        .padding(.top, 10)
    }
}

// Second page of the tutorial
struct Page2: View {
    let dWidth: Double
    let dHeight: Double
    
    var body: some View {
        Text("Home")
            .font(.largeTitle)
            .bold()
            .overlay {
                LinearGradient(
                    colors: [.red, .accentColor],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .mask(
                    Text("Home")
                        .font(.largeTitle)
                        .bold()
                )
            }
        Text("This is your home, in here you´re going to navigate to all the other views.")
            .font(.title3)
            .foregroundStyle(Color.white)
        Image("HomeScreenShot")
            .resizable()
            .scaledToFit()
            .clipShape(RoundedRectangle(cornerRadius: dWidth * 0.0636))
            .padding(.vertical, 10)
    }
}

// Third page of the tutorial
struct Page3: View {
    let dWidth: Double
    let dHeight: Double
    
    var body: some View {
        Text("Profile")
            .font(.largeTitle)
            .bold()
            .overlay {
                LinearGradient(
                    colors: [.red, .accentColor],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .mask(
                    Text("Profile")
                        .font(.largeTitle)
                        .bold()
                )
            }
        Text("To find your information and how you've been going through out the day, you just need to click the button in the top right corner.")
            .foregroundStyle(Color.white)
            .font(.title3)
        Image("ClickProf")
            .resizable()
            .scaledToFit()
            .clipShape(RoundedRectangle(cornerRadius: dWidth * 0.0636))
            .padding(.vertical, 10)
        Text("Here you can find information about: ")
            .font(.title3)
            .foregroundStyle(Color.white)
        HStack {
            Image(systemName: "rays")
            Text("Your weight")
                .font(.title3)
                .bold()
                .foregroundStyle(Color.white)
        }
        Spacer()
        HStack {
            Image(systemName: "rays")
            Text("Your height")
                .font(.title3)
                .bold()
        }
        .foregroundStyle(Color.white)
        Spacer()
        HStack {
            Image(systemName: "rays")
            Text("Your current streak")
                .font(.title3)
                .bold()
                .foregroundStyle(Color.white)
        }
        .foregroundStyle(Color.white)
        Spacer()
        HStack {
            Image(systemName: "rays")
            Text("Your Basal Metabolic Rate")
                .font(.title3)
                .bold()
                .foregroundStyle(Color.white)
        }
        .foregroundStyle(Color.white)
        Spacer()
        HStack {
            Image(systemName: "rays")
            Text("Your current macronutrients")
                .font(.title3)
                .bold()
                .foregroundStyle(Color.white)
        }
        .foregroundStyle(Color.white)
        Spacer()
        HStack {
            Image(systemName: "rays")
            Text("Your goals")
                .font(.title3)
                .bold()
                .foregroundStyle(Color.white)
        }
        .foregroundStyle(Color.white)
        Spacer()
    }
}

struct Page4: View {
    let dWidth: Double
    let dHeight: Double
    
    var body: some View {
        Text("Profile")
            .font(.largeTitle)
            .bold()
            .overlay {
                LinearGradient(
                    colors: [.red, .accentColor],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .mask(
                    Text("Profile")
                        .font(.largeTitle)
                        .bold()
                )
            }
        Image("ProfileScreenShot")
            .resizable()
            .scaledToFit()
            .clipShape(RoundedRectangle(cornerRadius: dWidth * 0.0636))
            .padding(.vertical, 10)
    }
}

struct Page5: View {
    let dWidth: Double
    let dHeight: Double
    
    var body: some View {
        Text("Search")
            .font(.largeTitle)
            .bold()
            .overlay {
                LinearGradient(
                    colors: [.red, .accentColor],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .mask(
                    Text("Search")
                        .font(.largeTitle)
                        .bold()
                )
            }
        Text("To look for meals that you cannot take pictures of or you have already eaten them, you can click the top left button.")
            .foregroundStyle(Color.white)
            .font(.title3)
        Image("ClickSearch")
            .resizable()
            .scaledToFit()
            .clipShape(RoundedRectangle(cornerRadius: dWidth * 0.0636))
            .padding(.vertical, 10)
        Text("This´ll open the search bar.")
            .foregroundStyle(Color.white)
            .font(.title3)
        Image("ClickedSearch")
            .resizable()
            .scaledToFit()
            .clipShape(RoundedRectangle(cornerRadius: dWidth * 0.0636))
            .padding(.vertical, 10)
        Text("( The search bar currently does not work )")
            .multilineTextAlignment(.center)
            .italic()
            .foregroundStyle(Color.white)
            .font(.title3)
    }
}

struct Page7: View {
    let dWidth: Double
    let dHeight: Double
    
    var body: some View {
        Text("Streak")
            .font(.largeTitle)
            .bold()
            .overlay {
                LinearGradient(
                    colors: [.red, .accentColor],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .mask(
                    Text("Streak")
                        .font(.largeTitle)
                        .bold()
                )
            }
        Text("The second gidget in the second row is a calendar that shows how many days you´ve achieved your goals.")
            .foregroundStyle(Color.white)
            .font(.title3)
        Image("CalendarShot")
            .resizable()
            .scaledToFit()
            .clipShape(RoundedRectangle(cornerRadius: dWidth * 0.0636))
            .padding(.vertical, 10)
    }
}

struct Page6: View {
    let dWidth: Double
    let dHeight: Double
    
    var body: some View {
        Text("Kcal Gidget")
            .font(.largeTitle)
            .bold()
            .overlay {
                LinearGradient(
                    colors: [.red, .accentColor],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .mask(
                    Text("Kcal Gidget")
                        .font(.largeTitle)
                        .bold()
                )
            }
        Text("The first gidget in the second row is a container of how many calories you´ve eaten in the day.")
            .foregroundStyle(Color.white)
            .font(.title3)
        Image("KcalShot")
            .resizable()
            .scaledToFit()
            .clipShape(RoundedRectangle(cornerRadius: dWidth * 0.0636))
            .padding(.vertical, 10)
    }
}

struct Page8: View {
    let dWidth: Double
    let dHeight: Double
    
    var body: some View {
        Text("Recommendations")
            .font(.largeTitle)
            .bold()
            .overlay {
                LinearGradient(
                    colors: [.red, .accentColor],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .mask(
                    Text("Recommendations")
                        .font(.largeTitle)
                        .bold()
                )
            }
        Text("In the end of the home there´s a set of recommendations based on what you usually eat.")
            .foregroundStyle(Color.white)
            .font(.title3)
        Image("RecomShot")
            .resizable()
            .scaledToFit()
            .clipShape(RoundedRectangle(cornerRadius: dWidth * 0.0636))
            .padding(.vertical, 10)
    }
}

struct Page9: View {
    let dWidth: Double
    let dHeight: Double
    
    var body: some View {
        Text("Scan Meal")
            .font(.largeTitle)
            .bold()
            .overlay {
                LinearGradient(
                    colors: [.red, .accentColor],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .mask(
                    Text("Scan Meal")
                        .font(.largeTitle)
                        .bold()
                )
            }
        Text("To scan a meal you just click the big red button in the start of home.")
            .foregroundStyle(Color.white)
            .font(.title3)
        Image("ScanShot")
            .resizable()
            .scaledToFit()
            .clipShape(RoundedRectangle(cornerRadius: dWidth * 0.0636))
            .padding(.vertical, 10)
    }
}

struct Page10: View {
    let dWidth: Double
    let dHeight: Double
    
    var body: some View {
        Text("Scan Meal")
            .font(.largeTitle)
            .bold()
            .overlay {
                LinearGradient(
                    colors: [.red, .accentColor],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .mask(
                    Text("Scan Meal")
                        .font(.largeTitle)
                        .bold()
                )
            }
        Text("Once clicked you´ll have to point the camera to the meal and your **Meal Pal** will identify it.")
            .foregroundStyle(Color.white)
            .font(.title3)
        Image("Scanning")
            .resizable()
            .scaledToFit()
            .clipShape(RoundedRectangle(cornerRadius: dWidth * 0.0636))
            .padding(.vertical, 10)
    }
}

struct Page11: View {
    let dWidth: Double
    let dHeight: Double
    
    var body: some View {
        Text("Scan Meal")
            .font(.largeTitle)
            .bold()
            .overlay {
                LinearGradient(
                    colors: [.red, .accentColor],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .mask(
                    Text("Scan Meal")
                        .font(.largeTitle)
                        .bold()
                )
            }
        Text("If you want to change the quantity of the meal just click the number in the quantity row.")
            .foregroundStyle(Color.white)
            .font(.title3)
        Image("Quantity")
            .resizable()
            .scaledToFit()
            .clipShape(RoundedRectangle(cornerRadius: dWidth * 0.0636))
            .padding(.vertical, 10)
    }
}

struct Page12: View {
    let dWidth: Double
    let dHeight: Double
    
    var body: some View {
        Text("Scan Meal")
            .font(.largeTitle)
            .bold()
            .overlay {
                LinearGradient(
                    colors: [.red, .accentColor],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .mask(
                    Text("Scan Meal")
                        .font(.largeTitle)
                        .bold()
                )
            }
        Text("If you are ready to add the food, just click the plus button in the top right corner.")
            .foregroundStyle(Color.white)
            .font(.title3)
        Image("Add")
            .resizable()
            .scaledToFit()
            .clipShape(RoundedRectangle(cornerRadius: dWidth * 0.0636))
            .padding(.vertical, 10)
    }
}

struct Page13: View {
    let dWidth: Double
    let dHeight: Double
    
    var body: some View {
        Text("Scan Meal")
            .font(.largeTitle)
            .bold()
            .overlay {
                LinearGradient(
                    colors: [.red, .accentColor],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .mask(
                    Text("Scan Meal")
                        .font(.largeTitle)
                        .bold()
                )
            }
        Text("If the app does not identify correctly the meal, try clicking the cross button in the top left corner, try it between 3 to 6 times.")
            .foregroundStyle(Color.white)
            .font(.title3)
        Image("Refresh")
            .resizable()
            .scaledToFit()
            .clipShape(RoundedRectangle(cornerRadius: dWidth * 0.0636))
            .padding(.vertical, 10)
    }
}

struct Page14: View {
    let dWidth: Double
    let dHeight: Double
    
    var body: some View {
        Text("Scan Meal")
            .font(.largeTitle)
            .bold()
            .overlay {
                LinearGradient(
                    colors: [.red, .accentColor],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .mask(
                    Text("Scan Meal")
                        .font(.largeTitle)
                        .bold()
                )
            }
        Text("If it is not the meal yet, try clicking the back button in the corner while you´re still looking at the food, and enter again the scanner.")
            .foregroundStyle(Color.white)
            .font(.title3)
        Image("Back")
            .resizable()
            .scaledToFit()
            .clipShape(RoundedRectangle(cornerRadius: dWidth * 0.0636))
            .padding(.vertical, 10)
    }
}

#Preview {
    GuideView(dWidth: 300, dHeight: 700)
}
