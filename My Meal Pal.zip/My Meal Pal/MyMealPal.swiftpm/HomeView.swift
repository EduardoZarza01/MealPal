//
//  HomeView.swift
//  MealPal
//
//  Created by Ultiimate Dog on 11/02/24.
//

import SwiftUI

struct HomeView: View {
    @ObservedObject var modelData: ModelData = .shared

    var body: some View {
        // Geometry needed to get the device dimensions
        GeometryReader { proxy in
            let dHeight = proxy.size.height
            let dWidth = proxy.size.width
            // Needed to navigate between views with buttons
            NavigationStack {
                ZStack {
                    VStack(spacing: 0) {
                        // Creates the toolbar
                        HStack {
                            SearchButton(dWidth: dWidth, dHeight: dHeight)
                            Spacer()
                            ProfileButton(dWidth: dWidth, dHeight: dHeight)
                        }
                        .frame(width: dWidth*0.9, height: dHeight*0.04)
                        // END toolbar
                        // Connects to the view that scans the food
                        NavigationLink {
                            FoodModelView().ignoresSafeArea()
                        } label: {
                            FoodIdentiferButton(dWidth: dWidth)
                        }
                        // END NavigationLink
                        HStack(spacing: 0) {
                            ProgressGidget(dWidth: dWidth)
                            CalendarGidget(dWidth: dWidth)
                        }
                        Spacer(minLength: 5)
                        // Creates the scrollView for the recommendations
                        ZStack {
                            QuickAddFrame(dWidth: dWidth, dHeight: dHeight)
                            VStack(spacing: 0) {
                                HStack {
                                    Text("| Meal                                  ")
                                    Spacer()
                                    Text("| 🔥")
                                    Text("| 🍗")
                                    Text("| 🍞")
                                    Text("| 🥑 |")
                                }
                                .frame(width: dWidth*0.83,height: 35)
                                .font(.title3)
                                .foregroundStyle(Color.white)
                                .bold()
                                ScrollView(showsIndicators: false) {
                                    VStack(spacing: 0) {
                                        Spacer(minLength: 5)
                                        QuickAddButton(dWidth: dWidth, dHeight: dHeight, index: 0)
                                        QuickAddButton(dWidth: dWidth, dHeight: dHeight, index: 1)
                                        QuickAddButton(dWidth: dWidth, dHeight: dHeight, index: 2)
                                        QuickAddButton(dWidth: dWidth, dHeight: dHeight, index: 3)
                                        QuickAddButton(dWidth: dWidth, dHeight: dHeight, index: 4)
                                        QuickAddButton(dWidth: dWidth, dHeight: dHeight, index: 5)
                                        QuickAddButton(dWidth: dWidth, dHeight: dHeight, index: 6)
                                        QuickAddButton(dWidth: dWidth, dHeight: dHeight, index: 7)
                                    }
                                }
                                .background(Color.white)
                                .clipShape(RoundedRectangle(cornerRadius: dWidth * 0.0636, style: .continuous))
                                .padding(.bottom)
                            }
                        }
                        // END ZStack
                }
                }
                .frame(width: dWidth, height: dHeight, alignment: .top)
            }
            .overlay {
                if modelData.showTutorial {
                    GuideView(dWidth: dWidth, dHeight: dHeight)
                }
            }
            // END Navigation
        }
        // END Geometry
    }
}

// This is for the frame of the recommendations
struct QuickAddFrame: View {
    let dWidth: Double
    let dHeight: Double
    
    var body: some View {
        Rectangle()
            .fill(Color.red)
            .cornerRadius(dWidth * 0.0636)
            .frame(width: dWidth*0.96)
    }
}

// These lines are used to maintain the slide feature to go back to another view
extension UINavigationController: UIGestureRecognizerDelegate {
    override open func viewDidLoad() {
        super.viewDidLoad()
        interactivePopGestureRecognizer?.delegate = self
    }
    public func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
        return viewControllers.count > 1
    }
}
// END

#Preview {
    HomeView()
}
